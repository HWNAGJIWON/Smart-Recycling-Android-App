package org.techtown.cameratest;

public class GeoDataClient {
}
