package org.techtown.cameratest;

public interface ClusterItem {
}
