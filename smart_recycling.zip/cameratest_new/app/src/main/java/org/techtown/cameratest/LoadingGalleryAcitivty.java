package org.techtown.cameratest;

import static org.techtown.cameratest.LoadingAcitivity.uploadImage;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoadingGalleryAcitivty extends AppCompatActivity {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sending_image_gallery);
        ProgressDialog customProgressDialog; // 여기도 추가함

        // 로딩창 추가
        // 로딩창 객체 생성
        customProgressDialog = new ProgressDialog(this);
        // 로딩창을 투명하게
        customProgressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        customProgressDialog.show();

        // 사용자 모르게 api 요청보내기

        String uri = globalVariable.getInstance().getGallerypath();
        System.out.println("[ENTER] LoadingGalleryActivity      /getResult");
        System.out.println("string_path : " + uri + "       /getResult");

//        File file = new File(uri);



        ImageView imageView = findViewById(R.id.imageView);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://35.216.17.148:5000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitInterface retrofitInterface = retrofit.create(RetrofitInterface.class);

        String file_name;

        try {
//            imageView.setImageURI(Uri.parse(globalVariable.getInstance().getGallerypath()));
//

            Uri photoUri = Uri.parse(uri);
            File tempFile;
            Cursor cursor = null;
            /*
             *  Uri 스키마를
             *  content:/// 에서 file:/// 로  변경한다.
             */
            String[] proj = { MediaStore.Images.Media.DATA };

            assert photoUri != null;
            cursor = getContentResolver().query(photoUri, proj, null, null, null);

            assert cursor != null;
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

            cursor.moveToFirst();

            tempFile = new File(cursor.getString(column_index));
            globalVariable.getInstance().setFilename(tempFile.getName()); // 파일명 저장

            uploadImage(retrofit, tempFile);

        } catch (Exception e) {

        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getData(retrofitInterface, globalVariable.getInstance().getFilename()); // 시간 지난 후 실행할 코드
                System.out.println("loading) getResult = "+ globalVariable.getInstance().getResult());
            }
        }, 4800);


        // 화면 3초후 전환 thread를 이용한 방법 -> 안되다가 갑자기 됨 , 애니메이션 때문인가?
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), Note.class);
                startActivity(intent);
            }
        }, 5500);
}

    private void getData(RetrofitInterface retrofitInterface, String filename) {
        // 일단 서버에 파일 명을 보내야해

        final String[] string = new String[1];

        retrofitInterface.getData(filename).enqueue(new Callback<JsonResult>() {
            @Override
            public void onResponse(Call<JsonResult> call, retrofit2.Response<JsonResult> response) {
                if (response.isSuccessful()) {

                    string[0] = new Gson().toJson(response.body());


                    Map<String, Object> map = new Gson().fromJson(string[0], Map.class);
                    for (Map.Entry<String, Object> entry : map.entrySet()) {

                        if (entry.getKey().equals("label")) {
                            globalVariable.getInstance().setResult((String) entry.getValue());
                        }
                    }
                }

            }

            @Override
            public void onFailure(Call<JsonResult> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "fail here????? response", Toast.LENGTH_LONG).show();
            }
        });


    }



}
