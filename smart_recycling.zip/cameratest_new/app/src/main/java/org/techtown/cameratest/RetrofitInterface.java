package org.techtown.cameratest;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RetrofitInterface {
    @Multipart
    @POST("photo")
    Call<RequestBody> uploadImage(@Part MultipartBody.Part part);


    /*
    보내는 방식 : http://35.216.109.26:5000/getJson/[파일명]
    http://35.216.109.26:5000/getJson/soju.png

     */


    @GET("getJson/{filename}")
    Call<JsonResult> getData(@Path("filename") String filename);


}