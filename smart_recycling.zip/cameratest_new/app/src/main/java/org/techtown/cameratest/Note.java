package org.techtown.cameratest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Note extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.note);


//        TextView goTrash = findViewById(R.id.goTrash); // 텍스트 -로 배출해주세요.

        TextView trashKindTextview = findViewById(R.id.trashKindTextview);
        ImageView imageView = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView2);
        TextView noticeDetailTextview = findViewById(R.id.noticeDetailTextview);
        //TextView noticeDetailNoteTextview = findViewById(R.id.noticeDetailNoteTextview);
        TextView noticeTextview1 = findViewById(R.id.noticeTextview1);

        System.out.println("Note activity) getResult = "+ globalVariable.getInstance().getResult());
        String result = globalVariable.getInstance().getResult();

        // 버튼추가
        Button button = (Button)findViewById(R.id.map_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gmap_intent = new Intent(getApplicationContext(), gMap.class);
                startActivity(gmap_intent);
            }
        });
        // 버튼추가
        Button button_superbin = (Button)findViewById(R.id.button_superbin);
        button_superbin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent superbinmap_intent = new Intent(getApplicationContext(), googleMapActivity.class);
                startActivity(superbinmap_intent);
            }
        });

        // 버튼 숨기기
        button.setVisibility(View.INVISIBLE);
        button_superbin.setVisibility(View.INVISIBLE);



        // 0 : 소주병
        if(result.equals("soju_bt")){
            imageView2.setImageResource(R.drawable.soju);
            noticeTextview1.setText("빈용기보증금제도란?");
            //noticeDetailNoteTextview.setText("빈용기보증금제도란?\n");
            noticeDetailTextview.setText("- 사용된 빈 병을 회수하고 재사용을 촉진하기 위해 제품의 가격에 빈용기보증금을 포함시켜 판매한다.\n" +
                    "- 소비자는 유리용기의 제품을 구입한 후, 빈용기 보증금 제품을 취급하고 있는 슈퍼, 대형마트 등의 소매점에 반환하면 보증금을 다시 돌려받을 수 있다.\n" +
                    "- 빈용기보증금 상담센터 : 1522-0082\n" +
                    "- 환불 가능한 빈 병 : 소주, 맥주, 청량음료\n" +
                    "- 190ml이상 400ml미만 : 100원\n" +
                    "- 400ml이상 1000ml미만 : 130원");
//            noticeDetailTextview.setText(result);
            trashKindTextview.setText("병");
//            goTrash.setText("으로 배출해주세요");

            imageView.setImageResource(R.drawable.glass1);

            // 패트/캔 버튼 숨기기
            button_superbin.setVisibility(View.GONE);
            button.setVisibility(View.VISIBLE);

        }
        // 1 : beer_bt : 맥주병
        else if(result.equals("beer_bt")){
//            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출해요.\n");
//            noticeDetailTextview.setText(result);
            trashKindTextview.setText("병");
//            goTrash.setText("으로 배출해주세요");
            noticeDetailTextview.setText("맥주병은 근처 편의점에서 공병으로 교환가능해요.\n");
            imageView.setImageResource(R.drawable.glass1);

            // 패트/캔 버튼 숨기기
            button_superbin.setVisibility(View.GONE);

        }
        // 2 : hanger : 행거
        else if(result.equals("hanger")){
//            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출해요.\n");
            trashKindTextview.setText("고철");
//            goTrash.setText("로 배출해주세요");
            noticeDetailTextview.setText(result);
            imageView.setImageResource(R.drawable.pet1);

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 3 : others_bt : 음료병, 쥬스병, 박카스병, 보증금 병이 아닌 다른 병들
        else if(result.equals("others_bt")){
//            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출해요.\n");
            trashKindTextview.setText("병");
//            goTrash.setText("으로 배출해주세요");
            noticeDetailTextview.setText(result);
            imageView.setImageResource(R.drawable.glass1);

            // 패트/캔 버튼 숨기기
            button_superbin.setVisibility(View.GONE);

        }
        // 4 : food_can : 참치캔, 스팸캔, 통조림캔
        else if(result.equals("food_can")){
//            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출해요.\n");
            trashKindTextview.setText("식품 캔");
//            goTrash.setText("으로 배출해주세요");
//            noticeDetailTextview.setText(result);
            imageView.setImageResource(R.drawable.can1); //마크
            imageView2.setImageResource(R.drawable.can_1); //png파일
            noticeTextview1.setText("철캔, 알루미늄 캔"); // 타일틀
            noticeDetailTextview.setText("- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 담배꽁초 등 이물질을 넣지 않고 배출한다.\n" +
                    "- 플라스틱 뚜껑 등 금속 캔과 다른 재질은 제거한 후 배출한다.");
            // 버튼 숨기기
            button.setVisibility(View.GONE);
            button_superbin.setVisibility(View.GONE);

        }
        // 5 : spray_can : 부탄가스, 스프레이 캔
        else if(result.equals("spray_can")){
//            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출해요.\n");
            noticeDetailTextview.setText(result);
            trashKindTextview.setText("캔");
//            goTrash.setText("으로 배출해주세요");
            imageView.setImageResource(R.drawable.can1);

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 6 : drink_can : 음료, 커피, 주류
        else if(result.equals("drink_can")){
//            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출해요.\n");
            noticeDetailTextview.setText(result);
            trashKindTextview.setText("캔");
//            goTrash.setText("으로 배출해주세요");
            imageView.setImageResource(R.drawable.can1);

            // 공병 버튼 숨기기
            button.setVisibility(View.GONE);


        }
        // 7 : pet : 페트병 (카페 플라스틱컵빼고 )
        else if(result.equals("pet")){
            imageView2.setImageResource(R.drawable.pet4);
            noticeTextview1.setText("페트병");
            noticeDetailTextview.setText("하나! 비운다\n" +
                    "둘 ! 뗀다\n" +
                    "셋 ! 누른다\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거해주세요.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거해주세요.\n" +
                    "- 뚜껑과 고리는 분리해도 좋고, 분리하지 않아도 괜찮아요!");
            imageView.setImageResource(R.drawable.pet1);
            trashKindTextview.setText("페트");
//            goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.GONE);
            button_superbin.setVisibility(View.VISIBLE);


        }
        // 8 : 식품용기, 밀폐용기(요거트)
        else if(result.equals("food_container_ps")){
            imageView2.setImageResource(R.drawable.plastic3);
            noticeTextview1.setText("플라스틱 종류별 배출요령");
            noticeDetailTextview.setText("[ 플라스틱 용기류 ]\n" +
                    "내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "세척되지 않은 컵라면 용기는 일반쓰레기로 버려주세요!\n" +
                    "\n" +
                    "[ 세제 ]\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "\n" +
                    "[ 기타 플라스틱 ]\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "- 칫솔과 볼펜은 플라스틱이 아니에요! 일반쓰레기로 버려주세요");
            imageView.setImageResource(R.drawable.plastic1);
            trashKindTextview.setText("플라스틱");
//            goTrash.setText("으로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.GONE);
            button_superbin.setVisibility(View.GONE);

        }
        // 9 : wash_ps : 샴푸, 린스, 바디워시, 세제
        else if(result.equals("wash_ps")){
            imageView2.setImageResource(R.drawable.plastic3);
            noticeTextview1.setText("플라스틱 종류별 배출요령");
            noticeDetailTextview.setText("[ 플라스틱 용기류 ]\n" +
                    "내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "세척되지 않은 컵라면 용기는 일반쓰레기로 버려주세요!\n" +
                    "\n" +
                    "[ 세제 ]\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "\n" +
                    "[ 기타 플라스틱 ]\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "- 칫솔과 볼펜은 플라스틱이 아니에요! 일반쓰레기로 버려주세요");
            imageView.setImageResource(R.drawable.plastic1);
            trashKindTextview.setText("플라스틱");
//            goTrash.setText("으로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.GONE);
            button_superbin.setVisibility(View.GONE);

        }
        // 10 : others_ps : 기타 플라스틱(스팸뚜껑, 장난감, 바구니... 등등)
        else if(result.equals("others_ps")){
            imageView2.setImageResource(R.drawable.plastic3);
            noticeTextview1.setText("플라스틱 종류별 배출요령");
            noticeDetailTextview.setText("[ 플라스틱 용기류 ]\n" +
                    "내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "세척되지 않은 컵라면 용기는 일반쓰레기로 버려주세요!\n" +
                    "\n" +
                    "[ 세제 ]\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "\n" +
                    "[ 기타 플라스틱 ]\n" +
                    "- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                    "- 부착상표, 부속품 등 본체와 다른 재질은 제거한 후 배출한다.\n" +
                    "- 칫솔과 볼펜은 플라스틱이 아니에요! 일반쓰레기로 버려주세요");
            imageView.setImageResource(R.drawable.plastic1);
            trashKindTextview.setText("플라스틱");
//            goTrash.setText("으로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.GONE);
            button_superbin.setVisibility(View.GONE);

        }
        // 11 : icepack : 아이스팩
        else if(result.equals("icepack")){
            noticeDetailTextview.setText("일반 아이스팩은 폐기물이라 일반 종량제 봉투에 담아 배출합니다.\n물 아이스팩은 뜯어 내용물을 비우고 겉의 비닐은 비닐류로 배출해주세요.");
            imageView.setImageResource(R.drawable.recycle);
            trashKindTextview.setText("아이스팩");
//            goTrash.setText("으로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 12 : food_vn : 과자, 라면봉지
        else if(result.equals("food_vn")){
                imageView2.setImageResource(R.drawable.vn_1);
                noticeTextview1.setText("과자, 라면 봉지");
                noticeDetailTextview.setText("- 내용물을 비우고 물로 헹구는 등 이물질을 제거하여 배출한다.\n" +
                        "- 흩날리지 않도록 봉투에 담에 배출한다.");
                imageView.setImageResource(R.drawable.vinyl1);
                trashKindTextview.setText("비닐");
//            goTrash.setText("으로 배출해주세요");

                // 버튼 숨기기
                button.setVisibility(View.GONE);
                button_superbin.setVisibility(View.GONE);

        }
        // 13 : coffee_vn : 커피 봉지
        else if(result.equals("coffee_vn")){
            noticeDetailTextview.setText("내용물을 비우고 물로 헹궈 이물질을 제거해 배출합니다.\n흩날리지 않도록 봉투에 담에 배출합니다.");
            imageView.setImageResource(R.drawable.vinyl1);
            trashKindTextview.setText("비닐");
//            goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 14 :  others_paper : 기타(휴지심, 컵 캐리어, 컵 슬리브)
        else if(result.equals("others_paper")){
            noticeDetailTextview.setText(result);
            imageView.setImageResource(R.drawable.paper1);
            trashKindTextview.setText("종이");
//            goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 15 :  box : 박스(과자상자,신발상자 포함)
        else if(result.equals("box")){
            noticeDetailTextview.setText("비닐코팅 부분, 상자에 붙어있는 테이프, 철핀 등을 제거한 후 압착하여 운반이 용이하도록 묶어서 배출합니다.\n");
            imageView.setImageResource(R.drawable.paper1);
//            trashKindTextview.setText("종이");goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }

        // 16 : others_vn : 마스크 비닐, 각종포장비닐, 택배비닐
        else if(result.equals("others_vn")){
            noticeDetailTextview.setText("내용물을 비우고 물로 헹궈 이물질을 제거해 배출합니다.\n흩날리지 않도록 봉투에 담에 배출합니다.");
            imageView.setImageResource(R.drawable.vinyl1);
//            trashKindTextview.setText("비닐");goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 17 : styrofoam : 스티로폼
        else if(result.equals("styrofoam")){
            noticeDetailTextview.setText("내용물을 비우고 물로 헹궈 이물질을 제거해 배출합니다.\n부착상표 등 스티로폼과 다른 재질은 제거한 후 배출합니다.\nTV 등 전자제품 구입시 완충제로 사용되는 발포합성수지 포장재는 가급적 구입처로 반납합니다.");
            imageView.setImageResource(R.drawable.recycle);
//            trashKindTextview.setText("스티로폼");goTrash.setText("으로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 18 : newspaper_book : 신문지, 책
        else if (result.equals("newspaper_book")){
            noticeDetailTextview.setText("신문지는 물기에 젖지 않도록하고 반듯하게 펴서 차곡차곡 쌓은 후 묶어서 배출합니다.\n양장본 책은 겉표지(일반쓰레기)와 속지(종이)를 분리해서 배출합니다.\n많은 양의 책이라면 상자에 넣거나 끈으로 묶어서 배출합니다.");
            imageView.setImageResource(R.drawable.paper1);
//            trashKindTextview.setText("종이");goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);
        }
        // 19 : note
        else if(result.equals("note")){
//            noticeDetailTextview.setText("비닐 코팅된 광고지, 공책의 스프링 등은 제거한 후 배출합니다.\n");
            noticeDetailTextview.setText("스프링을 제거해주세요");
            imageView.setImageResource(R.drawable.paper1);
//            trashKindTextview.setText("종이");goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 20 :  종이컵,종이팩(우유곽,음료팩,소주팩)
        else if(result.equals("cup_pack_paper")){
            noticeDetailTextview.setText("내용물을 비우고 물로 헹군 후 압착하여 봉투에 넣거나 한데 묶어서 배출합니다.\n");
            imageView.setImageResource(R.drawable.paper2);
//            trashKindTextview.setText("종이");goTrash.setText("로 배출해주세요");

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }
        // 21 : pet_cup : 일회용 플라스틱(사실 플라스틱아님) 컵
        else if(result.equals("pet_cup")){
                imageView2.setImageResource(R.drawable.pet_cup);
                noticeTextview1.setText("배출요령");
                noticeDetailTextview.setText("- 컵 표면에 색상이 인쇄된 플라스틱 컵은 재활용 하기 어려워요. 일반쓰레기로 버려주세요.\n" +
                        "- 컵을 감싸고 있는 종이 슬리브는 종이류로 배출해주세요.\n" +
                        "- 빨대는 일반쓰레기로 버려주세요.\n");
                imageView.setImageResource(R.drawable.recycle);
                trashKindTextview.setText("일회용 플라스틱컵");
//            goTrash.setText("으로 배출해주세요");

                // 버튼 숨기기
                button.setVisibility(View.GONE);
                button_superbin.setVisibility(View.GONE);

        }
        else{
            //noticeDetailTextview.setText("test.\n");
            imageView.setImageResource(R.drawable.recycle);

            // 버튼 숨기기
            button.setVisibility(View.INVISIBLE);
            button_superbin.setVisibility(View.INVISIBLE);

        }


    }
}
