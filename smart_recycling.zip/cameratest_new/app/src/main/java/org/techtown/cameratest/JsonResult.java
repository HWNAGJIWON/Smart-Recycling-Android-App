package org.techtown.cameratest;

import com.google.gson.annotations.SerializedName;

public class JsonResult {
    /*
    {'detections': 0, 'label': ' ', 'confidence': 0}
    {'detections': 1, 'label': 'food_can', 'confidence': 0.7427240610122681}
     */
    @SerializedName("detections")
    private String detections;
    @SerializedName("label")
    private String label;
    @SerializedName("confidence")
    private double confidence;


    public String getDetections() {
        return detections;
    }

    public void setDetections(String detections) {
        this.detections = detections;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }
}
