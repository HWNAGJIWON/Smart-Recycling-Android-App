package org.techtown.cameratest;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ResultActivity  extends AppCompatActivity {

//    static TextView textView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.result);
        String file_name = globalVariable.getInstance().getFilename();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://35.216.17.148:5000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitInterface retrofitInterface = retrofit.create(RetrofitInterface.class);

        ImageView imageView = findViewById(R.id.imageView);


        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    String uri = globalVariable.getInstance().getGallerypath();
                    imageView.setImageResource(Integer.parseInt(uri));

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "fail to get response", Toast.LENGTH_LONG).show();
                }

            }
        });


    }


    public static void println(String data) {
//        textView.append(data + "\n");
    }


    private void getData(RetrofitInterface retrofitInterface, String filename) {
        // 일단 서버에 파일 명을 보내야해

        final String[] string = new String[1];

        retrofitInterface.getData(filename).enqueue(new Callback<JsonResult>() {
            @Override
            public void onResponse(Call<JsonResult> call, retrofit2.Response<JsonResult> response) {
                if (response.isSuccessful()) {

                    string[0] = new Gson().toJson(response.body());


                    Map<String, Object> map = new Gson().fromJson(string[0], Map.class);
                    for (Map.Entry<String, Object> entry : map.entrySet()) {
                        if (entry.getKey().equals("label")) {
                            globalVariable.getInstance().setResult((String) entry.getValue());
                        }

                    }


                }

            }

            @Override
            public void onFailure(Call<JsonResult> call, Throwable t) {
//                Toast.makeText(getApplicatio?nContext(), "fail here????? response", Toast.LENGTH_LONG).show();
            }
        });
//        return string[0];
    }
}


    // file.getAbsPath() : 로컬>내부저장소>DCIM>CAMERA>현재시간.jpg
    /*private void uploadImage(Retrofit retrofit, File file) throws FileNotFoundException {
        // 사진저장경로 : 로컬>내부저장소>DCIM>CAMERA>현재시간.jpg

        // 1. 사진 원본 + 절대경로로 보내기
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);// 클라이언트 make
        MultipartBody.Part parts = MultipartBody.Part.createFormData("file", file.getName(), requestBody);

        RetrofitInterface retrofitInterface = retrofit.create(RetrofitInterface.class);
        Call call = retrofitInterface.uploadImage(parts);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, retrofit2.Response<ResponseBody> response) {
            }
            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
            }
        });

    }

     */
//
//
//    // 여기서 비트맵을 파일로 저장하는데?
//    private File getBitmapFile(Bitmap reducedBitmap) throws FileNotFoundException {
//
//        File file = new File(Environment.getExternalStorageDirectory() +"/DCIM/Camera/"+globalVariable.getInstance().getData());
//
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        reducedBitmap.compress(Bitmap.CompressFormat.JPEG, 0, bos);
//        byte[] bitmapdata = bos.toByteArray();
//
//        try{
//            file.createNewFile();
//            FileOutputStream fos = new FileOutputStream(file);
//            fos.write(bitmapdata);
//
//            fos.flush();
//            fos.close();
//            return file;
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//
//        return file;
//    }
//
//
//}
//
//
