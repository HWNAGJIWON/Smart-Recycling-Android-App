package org.techtown.cameratest;

public class globalVariable {

    private String result;
    public String getResult(){return result;}
    public void setResult(String result){this.result = result;}


    // detection == 찾았는지 아닌지, 근데 안 쓰는중
    private int detection=-1;
    public int getDetection(){return detection;}
    public void setDetection(int detection){this.detection = detection;}

    // gallerypath == uri 저장중
   private String gallerypath;// uri
    public String getGallerypath()
    {
        return gallerypath;
    }
    public void setGallerypath(String data)
    {
        this.gallerypath = data;
    }



    // data = filename
    private String imagefileName;
    public String getFilename()
    {
        return imagefileName;
    }
    public void setFilename(String data)
    {
        this.imagefileName = data;
    }


    private static globalVariable instance = null;
    public static synchronized globalVariable getInstance(){
        if(null == instance){
            instance = new globalVariable();
        }
        return instance;
    }
}
